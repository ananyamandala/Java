package gromming;

public class alphabet2 {
	public static void main(String[] args) {
		for (char i = 'a'; i <= 'd'; i++) {
			for (char j = 'a'; j <= 'd'; j++) {
				System.out.print(i + " ");
			}
			System.out.println();
		}

	}

}
// a a a 
//b b b b 
//c c c c 
//d d d d 