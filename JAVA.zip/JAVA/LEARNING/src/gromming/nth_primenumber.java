package gromming;

public class nth_primenumber {
	public static void main(String[] args) {
		int n = 5;
		int count = 0;
		int i = 1;

		while (n > 0) {
			i++;

			for (int j = 1; j <= i; j++) {
				if (i % j == 0) {
					count++;
				}
			}

			if (count == 2) {
				count++;
			
		
		if (count == n) {
			System.out.println(i);
		
			break;
		}
		}
		}
	}
}

	

