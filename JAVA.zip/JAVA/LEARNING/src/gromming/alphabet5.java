package gromming;

public class alphabet5 {
	public static void main(String[] args) {
		char ch = 'a';
		for (char i = 'a'; i <= 'd'; i++) {
			for (char j = 'a'; j <= i; j++) {
				System.out.print(ch+ " ");
				ch++;
			}
			System.out.println();

		}

	}
}
//a 
//b c 
//d e f 
//g h i j 

