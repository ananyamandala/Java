package gromming;

public class nth_strongnumber {
	public static void main(String[] args) {
		int num = 5;
		int count = 0,temp=n;
		for (int i = 1; count <= i; i++) {
			int n = 1, sum = 0, prod = 1;
			while (n > 0) {
				{
					
					int fact = 1;
					int rem = n % 10;
					{
						for (int i = rem; i >= 1; i--)
							fact *= i;

					}
					sum += fact;
					n = n / 10;
					
				}
				 if(sum==temp)
					{ 
					
					 count++;
					}
				 if(count==num) {
					 System.out.println(j);
					 break;
				 }

			}
		}
	}
}
