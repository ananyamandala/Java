package gromming;

public class nth_spy {

	public static void main(String[] args) {
		int num = 5;
		int count = 0;
		for (int i = 1; count <= i; i++) {
			//for(int i=1;true;j++)
			//for(int i=1;j>=0;j++)
			int n = 1, sum = 0, prod = 1;
			while (n > 0) {
				int rem = n % 10;
				sum += rem;
				prod *= rem;
				n /= 10;
			}

			if (sum == prod) {
				count++;

				if (count == num) {
					System.out.println(i);
					break;
				}
			}
		}
	}
}