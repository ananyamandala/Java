package gromming;

public class alphabet {
	public static void main(String[] args) {

        for (char i = 'a'; i <= 'd'; i++) { 
            for (char j = 'a'; j <= 'd'; j++) { 
                System.out.print(j+" "); 
            }
            System.out.println(); 
        }
    

}

}
//a b c d 
//a b c d 
//a b c d 
//a b c d 
