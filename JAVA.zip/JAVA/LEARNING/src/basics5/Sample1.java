package basics5;

public class Sample1 {
	private int a=30;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1 s=new Sample1();
		System.out.println(s.a);


	}

}
