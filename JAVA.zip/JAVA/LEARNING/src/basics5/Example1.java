package basics5;

import basics4.Sample1;

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1 a1=new Sample1();
		System.out.println(a1.a);
		

	}

}
