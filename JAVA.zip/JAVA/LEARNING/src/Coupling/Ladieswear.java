package Coupling;

public class Ladieswear implements Myntra{
	public double discount=0.5;

	@Override
	public void payment() {
		System.out.println("payment made with discount");
		
	}

}
