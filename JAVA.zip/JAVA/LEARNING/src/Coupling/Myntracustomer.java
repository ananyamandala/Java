package Coupling;
import java.util.Scanner;

public class Myntracustomer {
	

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("select your preferences");
	System.out.println("1.mens\n2.ladies");
	Myntra m;
	switch(sc.nextInt()) {
	case 1:m=new Menswear();
	m.payment();
	break;
	case 2:m=new Ladieswear();
	m.payment();
	break;
	default:System.out.println("category is not found");
	}

	}

}
