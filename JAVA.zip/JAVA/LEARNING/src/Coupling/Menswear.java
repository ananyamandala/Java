package Coupling;

public class Menswear implements Myntra{
	public double discountprice=0.3;

	@Override
	public void payment() {
		System.out.println("payment made with discount");
		
		
	}
	

}
