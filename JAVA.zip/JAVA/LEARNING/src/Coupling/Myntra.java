package Coupling;

public interface Myntra {
	void payment();

}
