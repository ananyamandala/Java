package Coupling;

public class Area {
	public void area() {
		Calculate c=new Calculate();
		System.out.println(c.length*c.breadth);
	}

	public static void main(String[] args) {
		Area area=new Area();
		area.area();
	

	}

}
