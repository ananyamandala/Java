package Coupling;

public class Calculate {
	public int length=10;
	public int breadth=12;

}
