package string;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		String s1="race";
		String s2="care";
		Arrays.sort(null);

	}

}
