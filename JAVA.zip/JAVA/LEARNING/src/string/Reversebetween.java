package string;

public class Reversebetween {

    public static void main(String[] args) {
        String s = "this is java class"; 
        String[] s1 = s.split(" ");
        String s2 = "";

        for (int i = 0; i < s1.length; i++) {
            String s3 = "";

            // Reverse only the second and last words
            if (i == 1 || i == s1.length - 1) {
                for (int j = s1[i].length() - 1; j >= 0; j--) {
                    s3 += s1[i].charAt(j);
                }
            } else {
                s3 = s1[i]; // Keep other words as they are
            }

            s2 += s3;

            if (i < s1.length - 1) {
                s2 += " ";
            }
        }

        System.out.println(s2);
    }
}
