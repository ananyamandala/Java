package string;

public class Stringlength {

	public static void main(String[] args) {
		String s="soumya";
		System.out.println(s.length());
		System.out.println("accesing from 0th index");
		for(int i=0;i<s.length();i++)
		{
			System.out.println(s.charAt(i));
		}
		System.out.println("accesing from last index");
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.println(s.charAt(i));
		}

	}

}
