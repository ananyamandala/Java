package string;

public class Unboxing {

	public static void main(String[] args) {
		int a=10;
		Integer a1=a;//implicit boxing
		int b=a1;//implicit unboxing
		int x=a1.intValue();//explicit unboxing
		System.out.println(x);
		System.out.println(b);
	}

}
