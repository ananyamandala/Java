package string;

public class Lengthstring {

	public static void main(String[] args) {
		String s="  This is java class";
		System.out.println(s.length());
	    for(int i=0;i<s.length();i++) {
	    	System.out.print(s.charAt(i));
	    }


	}

}
