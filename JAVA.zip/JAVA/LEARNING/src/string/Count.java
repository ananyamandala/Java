package string;

public class Count {

    public static void main(String[] args) {
        String s = "My name is soumya";
        String[] words = s.split(" "); 
        int wordCount = 0;

        for (int i = 0; i < words.length; i++) {
            wordCount++;
        }

        System.out.println("Number of words: " + wordCount);
    }
}
