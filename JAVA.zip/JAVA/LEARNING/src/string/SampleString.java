package string;

public class SampleString {

	public static void main(String[] args) {
		String s1="java";
		String s2="java";
		s1.concat("class");
		s2.concat("class");
		System.out.println(s1);
		System.out.println(s2);
	    s2="manual";
		System.out.println(s1);
		System.out.println(s2);

	    
		



	}

}
