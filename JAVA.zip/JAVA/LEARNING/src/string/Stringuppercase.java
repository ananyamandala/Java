package string;

public class Stringuppercase {

	public static void main(String[] args) {
		  String s = "Raju";
		  String str="";
		  for(int i=0;i<s.length();i++)
		  {
			  if(s.charAt(i)>='a'&&s.charAt(i)<='z') {
				str=str+(char)(s.charAt(i)-32);
			  }
			  else
				  str=str+s.charAt(i);
		  }
		  System.out.println(str);
	}
	
}

	   