package string;

public class Stringlowercase {

	public static void main(String[] args) {
		String s="INSTAGRAM";
		  String str="";
		  for(int i=0;i<s.length();i++)
		  {
			  if(s.charAt(i)>='A'&&s.charAt(i)<='Z') {
				str=str+(char)(s.charAt(i)+32);
			  }
			  else
				  str=str+s.charAt(i);
		  }
		  System.out.println(str);
	}
	
}

	   