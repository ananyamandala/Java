package string;
import java.util.*;
public class Array_List_Ex {

	public static void main(String[] args) {
		Collection a1=new ArrayList();
		a1.add(10);
		a1.add(20);
		a1.add(55.6);
		a1.add(null);
		a1.add(10);
		a1.add("hi");
		a1.add(null);
		a1.add(true);
		a1.add('c');
		System.out.println("add--->"+a1);
		Collection al1=new ArrayList();
		al1.add(10);
		al1.add(69);
		al1.add(false);
		al1.add("akash");
		al1.add("virat");
		al1.add('d');
		al1.add("  ");
		al1.add(null);
		//System.out.println("add--->"+al1);
		//al1.addAll(a1);
		//System.out.println("addAll--->"+al1);
		//a1.addAll(al1);
		//System.out.println("addAll--->"+a1);
		//a1.remove(null);
		//System.out.println("remove--->"+a1);
		//a1.removeAll(al1);
		//System.out.println("removeAll--->"+a1);
		//a1.removeAll(a1);
		//System.out.println("removeAll--->"+a1);
		//System.out.println(a1.contains(30));
		//System.out.println(a1.containsAll(al1));
		a1.retainAll(al1);
		System.out.println(a1);
		//System.out.println(a1.size());
		System.out.println(a1.isEmpty());
		a1.clear();
		System.out.println(a1);
		System.out.println(a1.isEmpty());
		
		
		
		

	}

}
