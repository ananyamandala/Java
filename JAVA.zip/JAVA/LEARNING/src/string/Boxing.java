package string;

public class Boxing {

	public static void main(String[] args) {
	int a=10;
	Integer a1=a;//implicit boxing
	Integer a2=Integer.valueOf(a);//explicit boxing 
	System.out.println(a1);
	System.out.println(a2);
	
	

	}

}
