package string;

public class Eachuppercase {

	public static void main(String[] args) {
	     String s = "this is java class";
	        String[] s1 = s.split(" ");
	        String s2 = null;
	        String s3="";

	        for (int i = 0; i < s1.length; i++) {
	        	s2=s1[i];
	        	for (int j = 0; j < s2.length(); j++) {	
	            	s3=s3+(char)(s2.charAt(j)-32);
	        	}
	        	if(i<s1.length-1) {
        		s3=s3+" ";
        	}	
	        }

	        System.out.println(s3);
	}
}
	        	
	        	
	   
	    
	    
	

