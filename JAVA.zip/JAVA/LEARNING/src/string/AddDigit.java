package string;

public class AddDigit {

	public static void main(String[] args) {
	    String s="1234";
	    int a=Integer.parseInt(s);
	    int rem=0,sum=0;
	    while(a>0)
	    {
	    	rem=a%10;
	    	sum+=rem;
	    	a/=10;
	    	
	    }
	    System.out.println(sum);

	}

}
