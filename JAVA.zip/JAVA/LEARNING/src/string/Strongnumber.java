package string;

public class Strongnumber {

	public static void main(String[] args) {
		System.out.println("Strong numbers from 1 to 1000:");

		for (int i = 1; i <= 1000; i++) {
			int n = i;
			int fact, rem, sum = 0, temp = n;

			while (n > 0) {
				fact = 1;
				rem = n % 10;

				for (int j = rem; j >= 1; j--) {
					fact =fact* j;
				}

				sum =sum+ fact;
				n=n/10;
				
			}

			if (sum == temp) {
				System.out.println(temp + " is a Strong number");
			}

			
		}
	}
}