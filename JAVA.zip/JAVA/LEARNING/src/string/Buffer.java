package string;

public class Buffer {

	public static void main(String[] args) {
	 StringBuffer s1=new StringBuffer("soumya");
	 s1.append("Mandala");
	 System.out.println(s1);

	}

}
