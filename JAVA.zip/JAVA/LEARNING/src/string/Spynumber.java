package string;

public class Spynumber {

	public static void main(String[] args) {
		System.out.print("Spy numbers from 1 to 1000: ");

		for (int i = 1; i <= 1000; i++) {
			int n = i;
			int sum = 0, prod = 1;

			while (n > 0) {
				int rem = n % 10;
				sum += rem;
				prod *= rem;
				n /= 10;
			}

			if (sum == prod) {
				System.out.println(i + " is spy number");
			}
		}
	}
}