
public class Upperwithoutsplit2 {

	public static void main(String[] args) {
	

		   
		        String s = "this is java class";
		        String s1 = "";
		        for (int i = 0; i < s.length(); i++) {
		            char ch = s.charAt(i);
                    if (i == 0 && ch >= 'a' && ch <= 'z') {
		                s1=s1+ (char)(ch - 32);  
		            } 
                   if (s.charAt(i - 1) == ' ' && ch >= 'a' && ch <= 'z') {
		                s1=s1+ (char)(ch - 32);  
		            } 
                    else {
		                s1 =s1+ ch;  
		            }
		        }

		        System.out.println(s1);
		    }
		}
