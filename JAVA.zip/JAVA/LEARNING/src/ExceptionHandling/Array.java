package ExceptionHandling;

public class Array {

	public static void main(String[] args) {
		int a[]= {123,678,345,123};

		try {
			
			System.out.println("try starts");
	
			System.out.println(a[20]);
		}
		catch(ArrayIndexOutOfBoundsException a1) {
		
			System.out.println(a1.getMessage());
			
		}
		System.out.println("main ends");
		

	}



	}


