package ExceptionHandling;

public class Lowercase {

	public static void main(String[] args) {
	   char ch='A';
	   int A=ch;
	   System.out.println();
	  

	}

}
