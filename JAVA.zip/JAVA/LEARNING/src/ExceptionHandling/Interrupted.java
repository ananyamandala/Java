package ExceptionHandling;
import java.util.Iterator;
public class Interrupted {

	public static void main(String[] args) throws InterruptedException {
	for(int i=1;i<=10;i++)	{
		System.out.println("*");
		Thread.sleep(2000);
	}
	}
}