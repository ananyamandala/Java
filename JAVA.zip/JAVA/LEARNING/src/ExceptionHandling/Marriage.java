package ExceptionHandling;
import java.util.Scanner;
public class Marriage {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				System.out.println("enter the age");
				int age=sc.nextInt();
				if(age>=21)
				{
					System.out.println("eligible");
				}
				try
				{
					throw new NoteligibleMarriageException("not");
				}
				catch (Exception e)
				{
					System.out.println(e.getMessage());
				}
		
	}

}
