package ExceptionHandling;

public class A {

	public static void main(String[] args) {
		System.out.println("main starts");
		try {
			System.out.println("try starts");
			System.out.println(10/0);
			System.out.println("try ends");
		}
		catch(ArithmeticException a1) {
			System.out.println("catch starts");
			System.out.println(a1.getMessage());
			System.out.println("catch ends");
			
		}
		System.out.println("main ends");
	}
}