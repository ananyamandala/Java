package ExceptionHandling;
import java.io.IOException;
public class IoException {
	public static void m1() throws IOException {
		m2();
	}
	public static void m2() throws IOException {
		throw new IOException();
	}

	public static void main(String[] args) throws IOException {
	     m1();

	}

}
