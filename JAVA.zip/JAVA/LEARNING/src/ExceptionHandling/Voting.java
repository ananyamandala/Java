package ExceptionHandling;

import java.util.Scanner;
public class Voting {

	public static void main(String[] args) throws NotEligibletoVoteException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age");
		int age=sc.nextInt();
		if(age>=18) {
			System.out.println("eligible to vote");
		}
		else {
			throw new NotEligibletoVoteException("not eligible");
		}
		

	}

}
