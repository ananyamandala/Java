package ExceptionHandling;

public class FinallyBlock1 {
	public static void main(String[] args) {
	System.out.println("main starts");

	try {
		System.out.println(10/0);
	}
	
	finally {
		System.out.println("database closed");
	}
	System.out.println("main ends");
	}
}





	

	