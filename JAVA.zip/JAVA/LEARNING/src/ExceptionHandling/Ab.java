package ExceptionHandling;

public class Ab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
