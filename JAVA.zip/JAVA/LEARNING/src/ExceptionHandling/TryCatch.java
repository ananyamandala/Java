package ExceptionHandling;

public class TryCatch {

	public static void main(String[] args) {
		System.out.println("hi");
		try
		{
			System.out.println(10/0);
		}

		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
