package ExceptionHandling;

public class Uppercase {

	public static void main(String[] args) {
        char ch='a';
        int a=ch;
        System.out.println(a);
        int x=65;
        char c=(char)x;
        System.out.println(c);
        System.out.println(a-32);

	}

}
