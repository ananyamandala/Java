package ExceptionHandling;

public class NotEligibletoVoteException extends Exception{
	public NotEligibletoVoteException(String s) {
		super(s);
	}

}
