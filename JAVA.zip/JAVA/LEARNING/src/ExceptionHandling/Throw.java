package ExceptionHandling;

public class Throw {

	public static void main(String[] args) {
		System.out.println("main starts");
		try{
			throw new Exception();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	
	
	System.out.println("main ends");
}
}

