package ExceptionHandling;

public class AIOBE {

	public static void main(String[] args) {
		int a[]= {123,678,345,123};
		System.out.println(a[20]);
		

	}

}
