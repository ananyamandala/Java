package ExceptionHandling;

public class ArithmeticException {

	public static void main(String[] args) {
		System.out.println("hi");
		System.out.println(20/0);
		System.out.println("hello");
		// TODO Auto-generated method stub

	}

}
