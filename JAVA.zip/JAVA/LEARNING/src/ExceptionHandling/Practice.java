package ExceptionHandling;

public class Practice {
    public void A() {
        System.out.println("hi");
    }
    
    class B extends Practice { // Now extending Practice
    
        public static void main(String[] args) {
            Practice practice = new Practice(); // Create instance of Practice
           
           practice.A();
        }
    }
}




