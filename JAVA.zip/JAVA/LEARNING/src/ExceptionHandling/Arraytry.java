package ExceptionHandling;



public class Arraytry {

    public static void main(String[] args) {
        System.out.println("main starts");
        try {
            System.out.println("try starts");
            System.out.println(10/0); 
            System.out.println("try ends");
        } 
        catch (ArithmeticException a2) {
            System.out.println();
            System.out.println(a2.getMessage());  
            System.out.println();
        }
        System.out.println("main ends");
    }
}
