package ExceptionHandling;

public class NoteligibleMarriageException extends RuntimeException{
	public NoteligibleMarriageException(String s) {
		super(s);
		
	}

}
