package ExceptionHandling;

public class Sample {

	public static void main(String[] args) {
		String s="java class";
		System.out.println("main starts");
		try {
			System.out.println("try starts");
			System.out.println(s.charAt(20));
			System.out.println("try ends");
		}
		catch(StringIndexOutOfBoundsException a1) {
			System.out.println();
			System.out.println(a1.getMessage());
			System.out.println();
		}
		System.out.println("main ends");
		

	}

}
