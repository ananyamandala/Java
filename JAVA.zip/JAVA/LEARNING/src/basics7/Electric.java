package basics7;

public interface Electric {
	void drive();
	

}
