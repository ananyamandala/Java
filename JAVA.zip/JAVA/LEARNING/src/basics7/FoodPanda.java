package basics7;

public class FoodPanda implements FoodDeliveryService {

	
	

	@Override
	public void Browsingrestuarnts() {
		System.out.println("Browsing restuarents for biryani ");
		
		
	}

	@Override
	public void Placingorder() {
		System.out.println("Placed order to my address");
		
	}

	@Override
	public void Trackingorder() {
		System.out.println("tracking the order ");
		
	}

}
