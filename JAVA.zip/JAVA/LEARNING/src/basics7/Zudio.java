package basics7;

public class Zudio {

	public static void main(String[] args) {
		
	        
	        Clothing c = new Clothing("Avvasa", 300.25, 0.1, "Clothing offer continues till the end of the week");

	
	        ElectronicStore e = new ElectronicStore("Washimg machine", 50000, 0.2, "Offer on electronics continues till the end of the month");

	    
	        c.handleCustomerEnquiry();
	        e.handleCustomerEnquiry();

	       
	        c.processSale();
	        e.processSale();
	}
}
