package basics7;

public class ElectronicStore extends ZudioStore{
	
	    private String product;
	    private double price;
	    private double discount;
	    private String query;

	    // Constructor
	    public ElectronicStore(String product, double price, double discount, String query) {
	        super();  // Calls the parent class constructor (if any)
	        this.product = product;
	        this.price = price;
	        this.discount = discount;
	        this.query = query;
	    }

	    @Override
	    public void handleCustomerEnquiry() {
	        System.out.println("Product is: " + product);
	        System.out.println("Price is: " + price);
	        System.out.println("Discount is: " + discount);
	        System.out.println("Total price = " + (price - (price * discount)));
	    }

	    

		@Override
		public void processSale() {
			   System.out.println("Sale is: " + query);
			
		}
	}


