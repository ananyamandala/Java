package basics7;

public class Model implements Electriccar{

	public static void main(String[] args) {
		Model m=new Model();
		m.chargebattery();
		m.drive();
		m.brand();
		// TODO Auto-generated method stub

	}

	@Override
	public void chargebattery() {
		System.out.println("ELECTRIC CAR WORKS ON BATTERY");
		
		
	}

	@Override
	public void drive() {
		System.out.println("CAR IS GOING TO HYD");
		
		
	}

	@Override
	public void brand() {
		System.out.println("BMW");
		
	}
	
	
	

}
