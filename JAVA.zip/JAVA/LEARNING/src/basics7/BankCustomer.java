package basics7;

public class BankCustomer {

	public static void main(String[] args) {
		SbiBank s=new SbiBank();
		s.applyloan();
		s.approveloan();
		s.cancelapplication();
		s.deposit();
		s.withdrawn();
	

	}

}
