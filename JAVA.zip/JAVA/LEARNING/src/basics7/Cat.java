package basics7;

public class Cat implements Animall{

	@Override
	public void sound() {
		System.out.println("meow ");
		
	}

	@Override
	public void eat() {
		System.out.println("eats chicken");
		
	}
	

}
