package basics7;

public interface LoanOperation {
	void applyloan();
	void approveloan();
	void cancelapplication();

}
