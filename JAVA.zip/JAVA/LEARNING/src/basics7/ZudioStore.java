package basics7;

public abstract class ZudioStore {
	
	   public abstract  void processSale();
	    public  abstract void handleCustomerEnquiry();
}


	