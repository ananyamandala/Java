package basics7;

public class Snake implements Animall{

	@Override
	public void sound() {
		System.out.println("silent");
		
	}

	@Override
	public void eat() {
		System.out.println("snakes eat frog");
		
	}
	

}
