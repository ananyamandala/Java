package basics7;

public class SbiBank implements BankingOperation,LoanOperation{


	@Override
	public void deposit() {
		System.out.println("Money is deposited");
	}

	@Override
	public void withdrawn() {
		System.out.println("money is withdrawn");
		
	}

	@Override
	public void applyloan() {
		System.out.println("applied loan");
		
	}

	@Override
	public void approveloan() {
	
		System.out.println("approve loan");
		
	}

	@Override
	public void cancelapplication() {
		System.out.println("applicationn is cancelled");
		
	}

}
