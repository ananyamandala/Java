package basics7;

public class Domestic {

	public static void main(String[] args) {
		Snake a=new Snake();
		a.sound();
		a.eat();
		Cat c=new Cat();
		c.sound();
		c.eat();
		Dog d=new Dog();
		d.sound();
		d.eat();
	}
		
	}
	
