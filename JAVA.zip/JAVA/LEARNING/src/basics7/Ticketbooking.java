package basics7;

public class Ticketbooking  implements Redbus{

	public static void main(String[] args) {
		 Ticketbooking r=new  Ticketbooking();
		  r.Searchingbuses();
		  r.Bookingticket();
		  r.Cancellingticket();
		

	}

	@Override
	public void Searchingbuses() {
		System.out.println("searching from HYD TO BANGLORE");
				
	}

	@Override
	public void Bookingticket() {
		System.out.println("Booked ticked from hyd to banglore");
		
	}

	@Override
	public void Cancellingticket() {
		
		System.out.println("cancelled  ticked from hyd to banglore");
		
	}

}
