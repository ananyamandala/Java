package basics7;

public class Nature {

	public static void main(String[] args) {
		Vulture v=new Vulture();
		v.fly();
		v.eat();
		// TODO Auto-generated method stub

	}

}
