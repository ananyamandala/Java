package basics7;

public interface Calc {
	void sub();

}
