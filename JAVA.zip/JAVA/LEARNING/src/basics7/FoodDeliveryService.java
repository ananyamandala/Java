package basics7;

public interface FoodDeliveryService {
	void Browsingrestuarnts();
	void Placingorder();
	void Trackingorder();
	
	

}
