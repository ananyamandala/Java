package basics7;

public class Vulture implements Animal,Bird{

	@Override
	public void fly() {
		System.out.println("Vulture fly high in the sky");
		
	}

	@Override
	public void eat() {
		System.out.println("vulture eat deadbodies");
		
	}
	

}
