package basics7;

public interface Animal {
	void eat();

}
