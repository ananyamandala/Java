package basics7;

public class Dog implements Animall{

	@Override
	public void sound() {
		System.out.println("bow bow");
		
	}

	@Override
	public void eat() {
		System.out.println("eats non-veg");
	}
	

}
