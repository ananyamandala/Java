package basics7;

public interface BankingOperation {
	void deposit();
	void withdrawn();

}
