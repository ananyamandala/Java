package basics7;

public interface Animall {
	void sound();
	void eat();

}
