package basics7;

public class Customer extends FoodPanda {

	public static void main(String[] args) {
			Customer f=new Customer();
			f.Browsingrestuarnts();
			f.Placingorder();
			f.Trackingorder();

		// TODO Auto-generated method stub

	}

}
