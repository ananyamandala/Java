package basics7;

public class Clothing extends ZudioStore{
	private String brand;
	private double price;
	private double discount;
	private String query;
	
	public Clothing(String brand,double price, double discount,String query) {
		super();
		this.brand=brand;
		this.price=price;
		this.discount=discount;
		this.query=query;
	}

	public void handleCustomerEnquiry() {
        System.out.println("Brand is: " + brand);
        System.out.println("Price is: " + price);
        System.out.println("Discount is: " + discount);
        System.out.println("Total price = " + (price - (price * discount)));
    }

   
   
	@Override
	public void processSale() {
		System.out.println("Sale is: " + query);
		
	}
}