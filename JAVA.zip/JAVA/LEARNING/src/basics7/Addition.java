package basics7;

public class Addition {
	public void add() {
		System.out.println(12+56);
	}

}
