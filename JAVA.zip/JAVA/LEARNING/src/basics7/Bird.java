package basics7;

public interface Bird {
	void fly();

}
