package basics7;

public class Calculation  extends Addition implements Calc{
	

	public static void main(String[] args) {
	Calculation c=new Calculation();
	c.add();
	c.sub();

	}

	@Override
	public void sub() {
		System.out.println(12-9);
		
	}

}
