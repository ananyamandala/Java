package basics7;

public interface Redbus {
	void Searchingbuses();
	void Bookingticket();
	void Cancellingticket();

}
