package basics7;

public interface Car {
	void chargebattery();
	
}
