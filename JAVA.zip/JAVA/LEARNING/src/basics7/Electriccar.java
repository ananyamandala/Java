package basics7;

public interface Electriccar extends Car,Electric{
	void brand();
	
	
}
 


