
public class Split {

	public static void main(String[] args) {
		String s="how are you";
		String [] s1=s. split(" ");
		System.out.println(s1.length);
	
		
	}

}
k