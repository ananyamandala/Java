import java.util.Scanner;

public class Stringarray {


		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			 System.out.println("Enter the size of the array:");
		        int size = sc.nextInt();

		        String s[] = new String[size];

		        System.out.println("Enter the array elements:");
		        for (int i = 0; i < s.length; i++) {
		            s[i] = sc.next(); 
		        }

		        System.out.println("The elements are:");
		        for (int i = 0; i < s.length; i++) {
		            System.out.println(s[i]);  
		        
		        
		    }
		}
}
		        
		        
		
		


