
public class Keithnumber {

	public static void main(String[] args) {
		int n=14;
		int count=0;
		int sum=0;;
		while(n>0)
		for(int i=1;i<=n;i++)
		{
			int rem=n%10;
			sum=sum+rem;
			int n1=0,n2=1;
			
			n1=n2;
			n2=sum;
		}
		System.out.println(sum);
		

	}

}
