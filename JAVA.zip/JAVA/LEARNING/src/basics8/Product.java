package basics8;

public class Product {
	private String name;
	private double price;
	private int manufacturedate;
	private double quantity;
	
	public void setName(String name) {
		this.name=name;
	}
	public String  getName(){
		return name;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	
	public double getPrice() {
		return price;
	}
	public void setManufacturedate(int manufacturedate) {
	this.manufacturedate=manufacturedate;
	}
	public int getManufacturedate() {
		return manufacturedate;
	}
	public void setQuantity(double quantity) {
		this.quantity=quantity;
	}
	public double getQuantity() {
		return quantity;
	}
}

	
	

