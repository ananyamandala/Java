package basics8;

public class ProductDetails {

	public static void main(String[] args) {
		Product p=new Product();
		p.setName("washing powder");
		p.setPrice(234.89);
		p.setManufacturedate(29);
		p.setQuantity(45.87);
		
		System.out.println(p.getName());
		System.out.println(p.getPrice());
		System.out.println(p.getManufacturedate());
		System.out.println(p.getQuantity());
		
		// TODO Auto-generated method stub

	}

}
