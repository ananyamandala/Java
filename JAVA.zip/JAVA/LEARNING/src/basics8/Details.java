package basics8;

public class Details {

	public static void main(String[] args) {
	Student s=new Student();
	s.setName("soumya");
	s.setId(123);
	s.setCourse("java");
	s.setMarks(12.45);
	
      
      
		System.out.println(s.getName());
		System.out.println(s.getId());
		System.out.println(s.getCourse());
		System.out.println(s.getMarks());
		
		
	}

}

