package basics8;

public abstract class Arithmetic {
	public abstract void add();
	public abstract void sub();
	
	

}
