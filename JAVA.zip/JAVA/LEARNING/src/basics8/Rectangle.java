package basics8;

public class Rectangle extends Drawing{
	public void CalculateArea() 
	
	{
	  int length=23;
	  int width=56;
	  System.out.println("Area of rectangle:"+length*width);
	}
}
