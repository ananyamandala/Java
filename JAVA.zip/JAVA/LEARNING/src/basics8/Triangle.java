package basics8;

public class Triangle extends Drawing {
public void CalculateArea() 
	
	{
	  int height =23;
	  int base=12;
	  System.out.println("Area of triangle :"+0.5*height*base);
	}
}


