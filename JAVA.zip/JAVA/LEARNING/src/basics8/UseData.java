package basics8;

public class UseData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Data a=new Data();
		System.out.println(a.getS());
		System.out.println(a.getD());
		System.out.println(a.getA());
		

	}

}
