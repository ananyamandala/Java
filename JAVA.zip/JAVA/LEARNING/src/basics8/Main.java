package basics8;

public class Main {
	
	    public static void main(String[] args) {
	        Shape shape = new Shape();
	        

	        double circleArea = shape.calculateArea(5.0);
	        System.out.println("Area of Circle: " + circleArea);
	        
	   
	        double rectangleArea = shape.calculateArea(4, 6.2);
	        System.out.println("Area of Rectangle: " + rectangleArea);
	               
	        double triangleArea = shape.calculateArea(8.4, 6);
	        System.out.println("Area of Triangle: " + triangleArea);
	    }
	}



