package basics8;

public class Ac extends Train {
	protected String ticketId;
	protected String trainname;
	protected double ticketprice;
	protected double discount;
	public Ac(String ticketId,String trainname,double ticketprice,double discount) {
		this.ticketId=ticketId;
		this.trainname=trainname;
		this.ticketprice=ticketprice;
		this.discount=discount;
		
	}
	public String ticketId() {
	
		return ticketId;
	}
	public double ticketprice() {
		
		ticketprice=ticketprice-(ticketprice*discount/100) ;
		 return ticketprice; 
	}
	public void displayDetails() {
		super.displayDetails();
		System.out.println("ticeket id :"+ticketId);
		System.out.println("train name :"+trainname);
		System.out.println("Total ticket price after applying discount :"+ticketprice());
	}
		
	}




