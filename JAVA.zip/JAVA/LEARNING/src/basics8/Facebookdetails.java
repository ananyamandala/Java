package basics8;

public class Facebookdetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
      Facebook f=new Facebook();
      f.setFirstname("soumya");
      f.setLastname("mandala");
      f.setMobilenumber(678954221);
      f.setDob("23-90=2014");
      f.setGender("f");
      
      
      
      
      
      System.out.println(f.getFirstname());
      System.out.println(f.getLastname());
      System.out.println(f.getMobilenumber());
      System.out.println(f.getDob());
      System.out.println(f.getGender());
     
	}

}
