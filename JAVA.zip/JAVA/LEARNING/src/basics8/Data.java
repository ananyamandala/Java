package basics8;

public class Data {
	private int a=10;
	private double d=56.98;
	private String  s="JAVA";

	public String getS() {
		return s;

	}
	public double getD() {
		return d;
		
	}
	public int getA() {
		return a;
	}

}
