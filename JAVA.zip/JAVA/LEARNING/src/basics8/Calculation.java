package basics8;
import java.util.Scanner;

public class Calculation {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("choose the shape");
		System.out.println("1.circle\n2.rectangle.\n3.triangle");
		switch(sc.nextInt())
		{
		case 1:Circle c=new Circle();
		       c.CalculateArea();
		       break;
		case 2:Rectangle r=new Rectangle();
	           r.CalculateArea();
	       break;
		case 3:Triangle t=new Triangle();
	           t.CalculateArea();
	       break;
		default:System.out.println("Not defined");
		}
		

	}

}
