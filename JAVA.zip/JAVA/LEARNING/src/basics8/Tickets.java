package basics8;

public abstract class Tickets {
	public abstract String  ticketId();
	public abstract double ticketprice();
	
	public void displayDetails() {
	System.out.println("--------TICKET DETAILS---------");
	
	
}
}

