package basics8;

public class Movieticket extends Tickets{
	protected String ticketId;
	protected double ticketprice;
	protected double discount;
	public Movieticket (String ticketId,double ticketprice,double discount) {
		this.ticketId=ticketId;
		this.ticketprice=ticketprice;
		this.discount=discount;
		

	}
	
	@Override
	public String ticketId() {
	
		return ticketId;
	}
	@Override
	public double ticketprice() {
		
	 ticketprice=ticketprice-(ticketprice*discount)/100 ;
	 return ticketprice;
	}
	public void displayDetails() {
		super.displayDetails();
		System.out.println("ticeket id"+ticketId);
		System.out.println("ticeket price"+ticketprice());
	}
		
	}



	

