package basics8;

public class User {

	public static void main(String[] args) {
		Child c=new  Child();
		c.m1();
		
		

	}

}
