package basics8;

public  class Child extends Parent{
	public void m1() {
		System.out.println("order biryani");
	}
	

}