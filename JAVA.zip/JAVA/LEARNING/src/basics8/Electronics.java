package basics8;

public class Electronics extends Product1{
	protected String brand;
	protected String warranty;
	protected double price;
	protected double discount;

	public Electronics(String productName,String productId,String brand,String warranty,double price,double discount) {
		super(productName,productId);
		this.brand=brand;
		this.warranty=warranty;
		this.price=price;
		this.discount=discount;
	
		
	}
	public double getPrice() {
		return price - (price * discount / 100);
	}
	
	public void displayDetails() {
		super.displayDetails();
		System.out.println("-----------------------");
		System.out.println("brand :"+brand);
		System.out.println("warranty :"+warranty);
		System.out.println("price :"+price);
		System.out.println("discount :"+discount);
		System.out.println("final price after discount: " + getPrice());
		
		
		
		
		
	}
	
	
	

}


