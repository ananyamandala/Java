package basics8;

public  abstract class Parent {
	public abstract void m1();

}
