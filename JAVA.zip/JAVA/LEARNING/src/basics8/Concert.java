package basics8;

public class Concert extends Tickets {
	protected String ticketId;
	protected double ticketprice;
	protected double servicefee;
	public Concert(String ticketId,double ticketprice,double servicefee) {
		this.ticketId=ticketId;
		this.ticketprice=ticketprice;
		this.servicefee=servicefee;
		
	
	}
	@Override
	public String ticketId() {
	
		return ticketId;
	}
	@Override
	public double ticketprice() {
		
		return ticketprice+servicefee ;
	}
	public void displayDetails() {
		super.displayDetails();
		System.out.println("ticeket id"+ticketId);
		System.out.println("ticeket price"+ticketprice());
	}
		
	}


