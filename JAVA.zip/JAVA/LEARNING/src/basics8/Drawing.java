package basics8;
import java.util.Scanner;
public class Drawing {
	public void CalculateArea()
	{
		System.out.println("calculate the area");
	}

}
