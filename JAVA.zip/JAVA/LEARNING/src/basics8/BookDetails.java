package basics8;

public class BookDetails {

	public static void main(String[] args) {
		
			Book s=new Book();
			s.setName("english");
			s.setPrice(123);
			s.setAuthor("james");
			s.setYearofpublish(2021);
			
		      
		      
				System.out.println(s.getName());
				System.out.println(s.getPrice());
				System.out.println(s.getAuthor());
				System.out.println(s.getYearofpublish());
				
				
			}

		}
		// TODO Auto-generated method stub