package basics8;

public class Student {
	private String name;
	private int id;
	private String course;
	private double marks;
	
	public void  setName(String name){
		this.name=name;
	}
	
	
	public String getName() {
		return name;

	}
	public void setId(int id){
		this.id=id;
	}
	
	
	public int getId() {
		return id;

	}
	public void setCourse(String course){
		this.course=course;
	}
	
	public String getCourse() {
		return course;

	}
	public void  setMarks(double marks){
		this.marks=marks;
	}
	
	
	public double getMarks() {
		return marks;

	}
	
}


