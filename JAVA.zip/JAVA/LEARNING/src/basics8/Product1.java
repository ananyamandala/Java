package basics8;

public abstract class Product1 {
	protected String productName;
	protected String productId;
	public Product1(String productName,String productId)
	{
		this.productName=productName;
		this.productId=productId;
	}
	public  abstract double getPrice();
	public void displayDetails() {
		System.out.println("product name:"+productName);
		System.out.println("product Id:"+productId);
		
	}
	
	

}
