package basics8;

public class DeclareanArray {

	public static void main(String[] args) {
		int a[]=new int[5];
		        a[0]=1;
				a[1]=6785;
				a[2]=987;
				a[3]=87;
				a[4]=899;
				System.out.println(a[0]);
				System.out.println(a[1]);
				System.out.println(a[2]);
				System.out.println(a[3]);
				System.out.println(a[4]);
				
				

	}

}
