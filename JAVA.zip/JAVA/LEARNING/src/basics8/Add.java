package basics8;

public abstract class Add extends Arithmetic {
	public void add() {
		System.out.println(10+78);
	}

}
