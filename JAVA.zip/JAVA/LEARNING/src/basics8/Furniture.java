package basics8;

public class Furniture {
public void utilization()
{
	System.out.println("utilised in the house");
}
}
