package basics8;

public class Sleeperclass extends Train{
	protected String ticketId;
	protected String trainname;
	protected double ticketprice;
	protected double servicecharge;
	public Sleeperclass(String ticketId,String trainname,double ticketprice,double servicecharge) {
		this.ticketId=ticketId;
		this.ticketprice=ticketprice;
		this.servicecharge=servicecharge;
		
	}
	@Override
	public String ticketId() {
	
		return ticketId;
	}
	@Override
	public double ticketprice() {
		
		return ticketprice+servicecharge ;
	}
	public void displayDetails() {
		super.displayDetails();
		System.out.println("ticKEt id :"+ticketId);
		System.out.println("Train name :"+ticketId);
		System.out.println("Total price"+ticketprice());
		System.out.println("---------------------------------");
		
	}
		
	}


