package basics8;

 public class Circle extends Drawing{
	public void CalculateArea() 
	{
	
			   double pi=3.14;
					int r=2;
			   System.out.println("area of circle:"+pi*r*r);
			   
				
			}

		}

 
	
	
