package basics8;

public class Amazon1 {

	public static void main(String[] args) {
		Book1 book=new Book1("java","m87","manjunathsir","yh765",87.98);
		Electronics e=new Electronics("ewr","ytd","IFB","2YEARS",45000,12.5);

		book.displayDetails();
		e.displayDetails();


	}

}
