package basics8;

public class Book1  extends Product1{
	protected String author;
	protected String ISBN;
	protected double price;
	public Book1(String productName,String productId,String author,String ISBN,double price ) {
		super(productName,productId);
		this.author=author;
		this.ISBN=ISBN;
		this.price=price;
		
	}
	public double getPrice() {
		return price;
	}
	
	public void displayDetails() {
		super.displayDetails();
		System.out.println("author :"+author);
		System.out.println("ISBN :"+ISBN);
		System.out.println("price :"+price);
		
		
		
		
	}
	
	
	

}
