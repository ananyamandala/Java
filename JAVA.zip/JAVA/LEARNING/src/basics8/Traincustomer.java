package basics8;

	import  java.util.Scanner;
	public class Traincustomer {

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Select the train");
			System.out.println("1.Sleeper class\n2.AC");
			
			switch(sc.nextInt())  {
			case 1:Sleeperclass s=new Sleeperclass("AT001","EXPRESS TRAIN ",500,50);
			s.displayDetails();
			break;
			case 2:Ac a=new Ac("AT001","LUXURY TRAIN",1500,15);
			a.displayDetails();  
			break;
			default:System.out.println("invalid");
				
			}
			

		}

	}


	