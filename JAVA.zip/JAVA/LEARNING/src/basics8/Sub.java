package basics8;

public class Sub extends Add {

	public static void main(String[] args) {
		Sub s=new Sub();
		s.add();
		s.sub(); 
		

	}

	@Override
	public void sub() {
		// TODO Auto-generated method stub
		System.out.println(12-6);
	}
	
}
	