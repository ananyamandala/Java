package basics8;
import  java.util.Scanner;

public class Moviecustomer {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Select the event");
		System.out.println("1.Concert\n2.Movie");
		
		switch(sc.nextInt())  {
		case 1: Concert c=new  Concert(null, 0, 0);
		c.displayDetails();
		break;
		case 2:Movieticket m=new Movieticket("rt65",12.6,67.8);
		m.displayDetails();
		break;
		default:System.out.println("invalid");
			
		}
		

	}

}
