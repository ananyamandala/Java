package arrays;

public class Arrayfibbonaci {
	public static void main(String[] args) {

		int arr[] = { 3, 6, 13, 17, 5, 4, 2 };

		for (int j = 0; j < arr.length; j++) {
			int a = 0, b = 1, sum = 0;
			for (int i = 0; i <= arr[j]; i++) {

				if (sum == arr[j]) {
					System.out.println(arr[j]);

				}

				sum = a + b;
				a = b;
				b = sum;

			}
		}
	}
}