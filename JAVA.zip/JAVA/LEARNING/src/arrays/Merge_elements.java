package arrays;

public class Merge_elements {
    public static void main(String[] args) {
        int i = 0;
        int j = 0;
        int[] a = {1, 7, 5, 8, 5};
        int[] b = {6, 2, 3, 0, 9};
        int[] c = new int[a.length + b.length];

        
        System.out.print("Merged Array: ");
        for (int k = 0; k < c.length; k++) {
            if (i < a.length) {
                c[k] = a[i];
                i++;
            } else {
                c[k] = b[j];
                j++;
            }
            System.out.print(c[k] + " "); 
        }
    }
}
