package arrays;

public class Car {
	String brandname;
	String carnumber;
	double price;
	int yearofmanufacture;
	String colour;
	public Car(String brandname,String carnumber,double price,int yearofmanufacture,String colour)
	{
		this.brandname=brandname;
		this.carnumber=carnumber;
		this.price=price;
		this.yearofmanufacture=yearofmanufacture;
		this.colour=colour;
				
	}

	@Override
	public String toString() {
		return "Car [brandname=" + brandname + ", carnumber=" + carnumber + ", price=" + price + ", yearofmanufacture="
				+ yearofmanufacture + ", colour=" + colour + "]";
	}

	public static void ml,ain(String[] args) {
      Car c1=new Car(".laudi","ts-1234",450000,1980,"white");
      System.out.println(c1);
		c1=new Car("benz","ts-4857",760000,2020,"blue");
		System.out.println(c1);
		
		
		

	}

}
