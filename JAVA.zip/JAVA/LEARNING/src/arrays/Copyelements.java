package arrays;

import java.util.Arrays;

public class Copyelements {

	public static void main(String[] args) {
		int []a= {5,7,12,1,6,4,15};
		int []b=new int[a.length];
		int i=0;
		for(int j=0;j<a.length;j++) {
			b[i]=a[j];
			i++;
		}
		System.out.println("using for loop");
			for(int k=0;k<b.length;k++) {
				//System.out.println(b[k]);
			}
			System.out.println("using for-Each loop");
			for(int obj:b)
				System.out.println(obj);
//	}
			System.out.println("using array class methods");
			//System.out.println(Arrays.toString(b));
	}
}
	
	
     
				
			
		

	


