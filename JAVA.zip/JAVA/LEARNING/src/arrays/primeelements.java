package arrays;

public class primeelements {
	public static void main(String[] args) {
		int a[] = { 2, 3, 5, 17, 11, 13 };

		for (int i = 0; i < a.length; i++) {
			int p = a[i];
			int count = 0;
			for (int j = 1; j <= p; j++) {
				if (p % j == 0) {
					count++;
				}
				if (count == 2) {// && a[i]==a[j]) {
					System.out.println(a[i]);
				}
			}

		}
	}

}
