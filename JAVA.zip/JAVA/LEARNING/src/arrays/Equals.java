package arrays;

public class Equals {

	public static void main(String[] args) {
		Equals e1=new Equals();
		Equals e2=new Equals();
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
		Equals e3=e2;
		System.out.println(e1.equals(e2));
		System.out.println(e2.equals(e3));
		
		
	}

}
