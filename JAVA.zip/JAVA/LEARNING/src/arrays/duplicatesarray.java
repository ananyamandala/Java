package arrays;

public class duplicatesarray {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int arr[]= {3,4,6,2,3,5,4};
	
	for(int i=0;i<arr.length-1;i++) {
		for(int j=i+1;j<arr.length;j++) {
			if(arr[i]== arr[j]) {
			System.out.println("duplicate values are:"+arr[i]);
			}
		}
	
}
	}
	
}
