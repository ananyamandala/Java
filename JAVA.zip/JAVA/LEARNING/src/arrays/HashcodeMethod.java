package arrays;

public class HashcodeMethod {

	public static void main(String[] args) {
		HashcodeMethod h1=new HashcodeMethod();
		HashcodeMethod h2=new HashcodeMethod();
		System.out.println(h1.hashCode());
		System.out.println(h2.hashCode());
		

	}

}
