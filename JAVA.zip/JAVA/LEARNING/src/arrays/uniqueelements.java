package arrays;

public class uniqueelements {
	public static void main(String[] args) {
		int a[]= {2,2,4,8,9,4,7,2,1,3,4,5,10};
		for(int i=0;i<a.length;i++) {
			int count=1;
			for(int j=i+1;j<a.length;j++) {
				if(a[i]==a[j]) {
					count++;
					a[j]=-1;
				}
			}
				if(a[i]!=-1 && count==1) {
						System.out.println(a[i]+"---->"+count);

	}

}
	}
}
