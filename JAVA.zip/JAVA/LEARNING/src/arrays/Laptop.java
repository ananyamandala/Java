package arrays;

import java.util.Arrays;
import java.util.Objects;

public class Laptop {
	String brandname;
    String version;
    double price;
    String colour;

    public Laptop(String brandname, String version, double price, String colour) {
        this.brandname = brandname;
        this.version = version;
        this.price = price;
        this.colour = colour;
    }

    @Override
    public String toString() {
        return "Laptop [brandname=" + brandname + ", version=" + version + ", price=" + price + ", colour=" + colour + "]";
    }


	@Override
	public boolean equals(Object obj) {
		Laptop
	}

	public static void main(String[] args) {
        Laptop l1 = new Laptop("laudi", "12th gen", 45000, "white");
        System.out.println(l1);
        Laptop l2 = new Laptop("HP", "13th gen", 76000, "blue");
        System.out.println(l2);
        System.out.println(l1 == l2); 
        System.out.println(l1.equals(l2)); 
    }
}