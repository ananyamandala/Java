package arrays;

public class mergearrays {
	public static void main(String[] args) {
		int a[] = { 2, 2, 4, 8, 9, 4, 7, 2, 1, 3, 4, 5, 10 };
		int b[] = { 2, 4, 6, 8, 10, 12, 14 };
		int i = 0;
		int j = 0;
		int c[] = new int[a.length + b.length];
		// for(int i=0;i<a.length;i++) {
		for (int k = 0; k < c.length; k++) {
			if (i < a.length) {
				c[k] = a[i];
				i++;

			} else {
				c[k] = a[j];
				j++;

			}
			System.out.println(c[k]);
		}

	}

}
