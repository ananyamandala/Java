package arrays;

public class HashcodeMethod1 {

	public static void main(String[] args) {

			HashcodeMethod1 h1=new HashcodeMethod1();
			HashcodeMethod1 h2=new HashcodeMethod1();
			HashcodeMethod1 h3=h2;
			System.out.println(h1.hashCode());
			System.out.println(h2.hashCode());
			System.out.println(h3.hashCode());
			

		}

	}
