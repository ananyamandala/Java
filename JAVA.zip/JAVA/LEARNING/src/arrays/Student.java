package arrays;

public class Student {
	String name;
	int id;
	public Student(String name,int id)
	{
		this.name=name;
		this.id=id;
	}
	public String toString() {
		return name+"  "+id;
	}

	public static void main(String[] args) {
		Student s1=new Student("soumya",1234);
		System.out.println(s1.name);
		System.out.println(s1.id);
		System.out.println(s1);
		s1=new Student("anan",879);
		System.out.println(s1);
		
		

	}
}

