package arrays;

public class bubblesort {

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			int[] a= {5,1,7,2,6,15,12,4};
	        for(int i=0;i<a.length;i++) {
	              // int min=i;
	       	 for(int j=0;j<a.length-1;j++)
	       			  {
	       		 if(a[j]>a[j+1]) {
	       			// min=j;
	       		int  temp=a[j];
	       		 a[j]=a[j+1];
	       		 a[j+1]=temp;
	       		 
	       	 }
	       	
	        }
	        }

	        for(int n=0;n<a.length;n++) {
	        	System.out.println(a[n]+" ");
}
	}
}

