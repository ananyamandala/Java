package arrays;

public class zigzag {
	public static void main(String[] args) {

		// TODO Auto-generated method stub
		int a[] = { 2, 4, 6, 8, 20, 10 };
		int b[] = { 3, 5, 7, 8, 21, 11 };
		int c[] = new int[a.length + b.length];
		int j = 0;
		int k = 0;
		for (int i = 0; i < c.length; i++) {
			if (j < a.length) {
				c[i] = a[j];
				i++;
				j++;
			}
			if (k < b.length) {
				c[i] = b[k];
				k++;
				// System.out.println(b[k]);
//						}
//					}
//					System.out.println("useing for each loop");
//					for(int o:c) {
//						System.out.println(o);
//					}
				System.out.println("using for loop");
				for (int n = 0; n < c.length; n++) {
					System.out.println(c[n] + "");
				}

				// System.out.println(Arrays.toString(c));

			}

		}

	}
}
