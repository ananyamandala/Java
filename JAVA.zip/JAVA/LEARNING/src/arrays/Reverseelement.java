package arrays;

public class Reverseelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = { 2, 4, 6, 8, 10, 12, 14 };
		int n = a.length - 1;
		for (int i = n; i >= 0; i--) {

			System.out.println(a[i]);
		}

	}
}
