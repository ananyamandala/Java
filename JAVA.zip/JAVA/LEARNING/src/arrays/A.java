package arrays;

public class A {
	int a=23;
	int b=234;


	@Override
	public String toString() {
		return "A [a=" + a + ", b=" + b + "]";
	}
		public static void main(String[] args) {
			A a1=new A();
			System.out.println(a1.toString());
		}
	}


