package basics3;

public class Mobile extends Amazon{
	public void payment() {
		System.out.println("payment made for mobile");
	}

}
