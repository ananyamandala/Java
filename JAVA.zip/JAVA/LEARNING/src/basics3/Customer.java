package basics3;
import java.util.Scanner;

 public class Customer {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose the product and make the payment through online");
		System.out.println("1.shoes\n2.mobiles");
		switch(sc.nextInt())
		{
		  case 1:Shoes shoe=new Shoes();
		         shoe.payment();
		          break;
		
		case 2:Mobile mobile=new Mobile();
		      mobile.payment();
		      break;
		default:System.out.println("Product not available");
		}
	}
 }
		
		
		
		

