package basics3;

public class Sample {
	private static int a=10;
	static void m1()
	{
			System.out.println("hello");
	}
	public static void main(String[] args) {
		Sample a1=new Sample();
		System.out.println(a);
		a1.m1();
	}
}
	
	

