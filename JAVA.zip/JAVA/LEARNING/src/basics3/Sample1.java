package basics3;

  public class Sample1 {
  protected static   int a=70;
  protected void m1()
  {
	  System.out.println("hi");    
  }

	public static void main(String[] args) {
		Sample s=new Sample();
		System.out.println(a); 
		s.m1();
	}

}
