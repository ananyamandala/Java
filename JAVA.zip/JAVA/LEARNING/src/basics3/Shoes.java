package basics3;

public class Shoes extends Amazon{


	public void payment() {
		System.out.println("payment made for shoes");
	}
	

}
