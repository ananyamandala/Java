package basics3;

public class Father {
 public void marriage()
 {
	 System.out.println("marry radhika");
	 
 }
	

}
