package basics3;

public class Amazon {
	public void payment() {
	System.out.println("online payment");
		
	}

}
