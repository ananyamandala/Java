
package basics3;


public class Son extends Father{
	public void marriage()
	{
		System.out.println("no i will marrt lilly");
	}


	public static void main(String[] args) {
		Son a1=new Son();
		a1.marriage();
		

	}

}

