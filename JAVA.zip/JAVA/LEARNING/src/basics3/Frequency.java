package basics3;
import java.util.Scanner;
public class Frequency {

	public static void main(String[] args) {
		String s="Hello World";
		Scanner sc=new Scanner(System.in);
		System.out.println(s);
		System.out.println("enter the character");
      
        int count=0;
        for(int i=0;i<s.length();i++)
        {
        	if(s.charAt(i)==s) {
        		count++;
        	}
        }
        System.out.println(count);
        
}
}
