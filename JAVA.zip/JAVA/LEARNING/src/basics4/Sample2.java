package basics4;

public class Sample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1 a1=new Sample1();
		System.out.println(a1.a);

	}

}
