package basics4;

public class Reversing {

    public static void main(String[] args) {
        String s = "this is java class"; // output = siht si avaj ssalc
        String[] s1 = s.split(" ");
        String s2 = "";

        for (int i = 0; i < s1.length; i++) {
            String s3 = ""; 

            for (int j = s1[i].length() - 1; j >= 0; j--) {
                s3 = s3 + s1[i].charAt(j);
            }
            
            s2 = s2 + s3;
            
            if (i < s1.length - 1) {
                s2 = s2 + " ";
            }
        }

        System.out.println(s2);
    }
}
