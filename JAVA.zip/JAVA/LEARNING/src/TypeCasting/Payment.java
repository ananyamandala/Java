package TypeCasting;
import java.util.Scanner;

public class Payment {

		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);
		        System.out.println("Select the product:");
		        System.out.println("1. Milk\n2. Bread\n3. Biscuit");

		        

		        switch (sc.nextInt()) {
		            case 1:
		                Milk milk = new Milk(1500, 18, 4, 12);
		                milk.displaydetails();
		                break;
		            case 2:
		                Bread bread = new Bread(200, 10, 6, 10);
		                bread.displaydetails();
		                break;
		            case 3:
		                Biscuit biscuit = new Biscuit(100, 5, 10, 5);
		                biscuit.displaydetails();
		                break;
		            default:
		                System.out.println("Invalid choice.");
		                break;
		        }
		    }
}
		        
		    
		    

		       
		    
		


	


