package TypeCasting;

public class Child1 extends Parent1{

		int y=243;
		

		public void m4() {
			System.out.println("Non Static method Child ");
		}



	public static void main(String[] args) {
		Parent1 p=new Child1();//upcasting
		System.out.println(p.b);
		p.m2();
		 Child1 c=(Child1)p;
		// System.out.println(c.y);downcasting
		//	c.m4();
		 

		


	}

}


	
	


