package TypeCasting;

public class Parent {
	static  int a=10;
	int b=23;
	public static void m1() {
		System.out.println("Static method");
	}
	public void m2() {
		System.out.println("Non Static method");
	}

}
