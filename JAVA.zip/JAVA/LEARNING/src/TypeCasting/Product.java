package TypeCasting;

public abstract  class Product {
	public abstract double mrp();
	public abstract double gst();
	public abstract int quantity();
	public void displayDetails()
	{
		System.out.println("--------PRODUCT DETAILS--------");
	

}
}
