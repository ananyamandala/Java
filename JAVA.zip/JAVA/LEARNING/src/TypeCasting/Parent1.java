package TypeCasting;

public class Parent1 {

		int b=23;
		public void m2() {
			System.out.println("Non Static method");
		}

	}


