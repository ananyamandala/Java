package TypeCasting;

public class Chair extends Furniture {
	public void chair(){
		System.out.println("used to sit");
	}

	public static void main(String[] args) {
		Furniture f=new Furniture();
		Chair c=(Chair)f;//downcastig the object which is not upcasted
		

	}

}
