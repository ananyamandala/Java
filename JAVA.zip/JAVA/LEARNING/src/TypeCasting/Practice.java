package TypeCasting;

public class Practice {
	
		static int a=10;
		int b=80;
		public static void m1()
		{
			System.out.println("static method");
			
		}
		public void m2()
		{
			System.out.println("non static method");
			
		}
		public static void main(String[]args)
		{
			int c=70;
			System.out.println(a);
			System.out.println(b);
			m1();
			m2();
		}
	}


	