package TypeCasting;

public class Child extends Parent{
	

		static  int x=678;
		int y=243;
		public static void m3() {
			System.out.println("Static method Child");
		}
		public void m4() {
			System.out.println("Non Static method Child ");
		}



	public static void main(String[] args) {
		Parent p=new Child();
		System.out.println(p.a+" "+p.b);
		p.m2();
		m1();
		System.out.println(p.x+" "+p.y);
		p.m4();
		m3();
		


	}

}
