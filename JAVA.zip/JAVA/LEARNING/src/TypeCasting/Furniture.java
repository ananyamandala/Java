package TypeCasting;

public class Furniture {
	public void utilization()
	{

		System.out.println("used for utilization");
}
}
