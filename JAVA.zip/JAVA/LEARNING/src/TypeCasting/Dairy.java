package TypeCasting;

public abstract  class Dairy {
		public abstract int mrp();
		public abstract double gst();
		public abstract int quantity();
		public void displaydetails()
		{
			System.out.println("--------PRODUCT DETAILS--------");
		

	}
		this.mrp=mrp;
		this.gst=gst;
		this.quantity=quantity;
		this.discount=discount;
	}

	@Override
	public int mrp() {
		
		 
				if(mrp>=500)
				{
					System.out.println("total price="+mrp/50*100);
				}
				else 
				{
					System.out.println(mrp);
				}
				
				return mrp;
					
	}

	@Override
	public double gst() {
		// TODO Auto-generated method stub
		return mrp*gst;
	}

	@Override
	public int quantity() {
		// TODO Auto-generated method stub
		return quantity;
	}
	public void displaydetails() {
		super.displaydetails();
		
		System.out.println(gst());
		System.out.println(quantity);
		
		System.out.println("TOTAL PRICE PAID BY CUSTOMER"+mrp());
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
