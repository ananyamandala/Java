package TypeCasting;

import java.util.Scanner;

public class Milk extends Product {
	
    
    protected double mrp;       
    protected double gst;       
    protected double discount;  
    protected int quantity;     
    
 
    public Milk(double mrp, double gst, int quantity, double discount) {
        this.mrp = mrp;
        this.gst = gst;
        this.quantity = quantity;
        this.discount = discount;
    }

    @Override
    public double mrp() {
        
        double totalPrice;
        if (this.mrp > 500) {
            
            totalPrice = (mrp * (1 - discount / 100) * (1 + this.gst / 100) * this.quantity);
        } else {
          
            totalPrice = (mrp * (1 + this.gst / 100) * this.quantity);
        }
        return totalPrice;
    }


    @Override
    public double gst() {
        // Return GST amount based on the product price
        return (mrp * this.gst / 100) * quantity; // Correctly calculate the total GST
    }

    @Override
    public int quantity() {
        return quantity;
    }

    public void displayDetails() {
        // Display product details
        System.out.println("--------PRODUCT DETAILS--------");
        System.out.println("MRP:"+mrp);
        System.out.println("DISCOUNT;"+discount);
        System.out.println("GST Amount: " + gst());
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Price Paid by Customer: " + mrp());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Select the product: ");
        System.out.println("1. Milk\n2. Bread\n3. Biscuit");
        
      
        switch (sc.nextInt()) {
            case 1:
                Milk milk = new Milk(1500, 18, 4, 12);
                System.out.println("product:Milk ");

                milk.displayDetails();
                break;
            case 2:
              Milk m2 = new Milk(200, 10, 6, 10); 
              System.out.println("product:Bread ");
                m2.displayDetails();
                break;
            case 3:
            	Milk m3 = new Milk(100, 5, 10, 5); 
            	System.out.println("product:Biscuit ");
                m3.displayDetails();
                
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }

        
    }
}
