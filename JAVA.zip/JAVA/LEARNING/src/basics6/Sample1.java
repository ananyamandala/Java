package basics6;

public class Sample1 {
	protected int a=10;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1 s=new Sample1();
		System.out.println(s.a);

	}

}
