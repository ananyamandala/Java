import java.util.Scanner;
public class Frequency {

	public static void main(String[] args) {
		String s="javaclass";
		Scanner sc=new Scanner(System.in);
		System.out.println(s);
		System.out.println("enter the character");
		char ch=sc.next().charAt(0);
		int count=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)==ch) {
				count++;
			}
		}
		System.out.println(count);

		
				

	}

}
