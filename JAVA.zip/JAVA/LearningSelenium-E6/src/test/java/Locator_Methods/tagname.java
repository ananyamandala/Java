package Locator_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class tagname {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		// launch the browser
		WebDriver driver = new ChromeDriver();
		// navigate to the url
		driver.get("https://demowebshop.tricentis.com/");

		// identify the register hyper link
		WebElement registrlink = driver.findElement(By.partialLinkText("Regi"));

		// perforn action---->click
		registrlink.click();

		// identify the click on radiobutton=female

		driver.findElement(By.id("gender-female")).click();
		// identify the firstnaame and enter data
		driver.findElement(By.id("FirstName")).sendKeys("mandala");

		// identify the lastnaame and enter data
		driver.findElement(By.id("LastName")).sendKeys("soumya");
		// identify the email and enter data
		driver.findElement(By.id("Email")).sendKeys("soumya789@gmail.com");

		// identify the passwordand enter data
		driver.findElement(By.id("Password")).sendKeys("auni1422k");

		// identify the passwordand enter data
		driver.findElement(By.id("ConfirmPassword")).sendKeys("auni1422k");

		// identify the register button and enter data
		driver.findElement(By.id("register-button")).click();
		Thread.sleep(3000);

		driver.quit();
		System.out.println("execution completed ");

	}

}
