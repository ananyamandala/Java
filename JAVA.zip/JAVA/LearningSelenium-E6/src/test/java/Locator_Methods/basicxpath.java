package Locator_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class basicxpath {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		// launch the browser
		WebDriver driver = new ChromeDriver();
		// navigate to the url
		driver.get("file:///C:/Users/manda/Downloads/webpage.html");

		// identify the click on name

		driver.findElement(By.xpath("//input[@id='name']")).clear();
		driver.findElement(By.xpath("//input[@id='name']")).sendKeys("soumya");
		// identify the email and enter data
		driver.findElement(By.xpath("//input[contains(@name,'ma')]")).sendKeys("mandala123@gmail.com");

		// identify the password and enter data
		driver.findElement(By.xpath("//input[contains(@placeholder,'Pass')]")).sendKeys("soumya123");
		// identify the mobile and enter data
		driver.findElement(By.xpath("//input[@id='mobile']")).sendKeys("743289087");

		// identify the gender button and enter data
		driver.findElement(By.xpath("//input[contains(@id,'fem')]")).click();

		// identify the place and enter data
		driver.findElement(By.xpath("//input[@id='manali']")).click();
		// identify thefeedback and enter data
		driver.findElement(By.xpath("//textarea[@id='feedback']")).sendKeys("good performance");
		// identify the contact us and enter data
		driver.findElement(By.xpath("//a[contains(text(),'Us')]")).click();

		driver.quit();
		System.out.println("execution completed ");

	
	}

}
