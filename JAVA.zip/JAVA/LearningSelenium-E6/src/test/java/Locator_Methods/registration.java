package Locator_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class registration {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		// launch the browser
		WebDriver driver = new ChromeDriver();
		// navigate to the url
		driver.get("file:///C:/Users/manda/Downloads/webpage.html");

		// identify the click on name

		driver.findElement(By.name("name")).clear();
		driver.findElement(By.name("name")).sendKeys("soumya");
		// identify the email and enter data
		driver.findElement(By.name("email")).sendKeys("mandala123@gmail.com");

		// identify the password and enter data
		driver.findElement(By.name("password")).sendKeys("soumya123");
		// identify the mobile and enter data
		driver.findElement(By.name("mobile")).sendKeys("743289087");

		// identify the gender button and enter data
		driver.findElement(By.id("female")).click();

		// identify the place and enter data
		driver.findElement(By.id("manali")).click();
		// identify thefeedback and enter data
		driver.findElement(By.id("feedback")).sendKeys("good performance");
		// identify the contact us and enter data
		driver.findElement(By.tagName("a")).click();

		driver.quit();
		System.out.println("execution completed ");

	}

}
