package Locator_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class absolute {
	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		// launch the browser
		WebDriver driver = new ChromeDriver();
		// navigate to the url
		driver.get("file:///C:/Users/manda/Downloads/webpage.html");

		// identify the click on name

		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[1]/td[2]/input")).clear();
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[1]/td[2]/input")).sendKeys("soumya");
		// identify the email and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[2]/td[2]/input"))
				.sendKeys("mandala123@gmail.com");

		// identify the password and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[3]/td[2]/input")).sendKeys("soumya123");
		// identify the mobile and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[4]/td[2]/input")).sendKeys("743289087");

		// identify the gender button and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[6]/td[2]/input[2]")).click();

		// identify the place and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[7]/td[2]/input[2]")).click();
		// identify thefeedback and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[9]/td[2]/textarea"))
				.sendKeys("good performance");
		// identify the contact us and enter data
		driver.findElement(By.xpath("html/body/form/fieldset/table/tbody/tr[11]/td[2]/a")).click();

		driver.quit();
		System.out.println("execution completed ");

	}
}
