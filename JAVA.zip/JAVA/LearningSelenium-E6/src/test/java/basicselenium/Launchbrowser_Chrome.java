package basicselenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Launchbrowser_Chrome {

	public static void main(String[] args) {
		// Configure the browser
		WebDriverManager.chromedriver().setup();

		// Launch the browser
	WebDriver driver=new ChromeDriver();
	
	//navigate to the application via URL
	driver.get("https://www.google.com/  ");

	
	//close  the browser
	driver.close();
	System.out.println("test completed");

	}

}
