package basicselenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Launchbrowser_edge {

	public static void main(String[] args) {

	//configure the browser
	WebDriverManager.edgedriver().setup();	
	
	//launch the browser
	WebDriver driver=new EdgeDriver();
		//navigate the application via URL
	  driver.get("https://www.google.com/  ");
		//close the browser
	  driver.close();
	  //execution log
	  System.out.println("test completed");
	}
}