package basicselenium;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lauchmultiple_browsers {

	public static void main(String[] args) {
		WebDriver driver =null;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the browser");
		String browser=sc.next();
		if(browser.equals("chrome")) {
			//configure the browser
			WebDriverManager.chromedriver().setup();
			//launch the browser
			driver=new ChromeDriver();
		}else if(browser.equals("firefox")) {
			//configure the browser
			WebDriverManager.edgedriver().setup();
			//launch the browser
			driver=new EdgeDriver();
			
		}
		else {
		System.out.println("not found");
		}
		driver.get("\"https://www.facebook.com\"");
		
		
		
	}

}
