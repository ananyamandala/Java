package basicselenium;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Launch_multiple {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("select the number");
	    int choice=sc.nextInt();
		WebDriverManager.edgedriver().setup();	
		
		
		WebDriver driver=new EdgeDriver();
		switch (choice) {
        case 1:
            driver.get("https://www.google.com");
            break;
        case 2:
            driver.get("https://www.youtube.com");
            break;
        case 3:
            driver.get("https://www.facebook.com");
           default:System.out.println("");
		}
	}
}
            
        