package Webdriver_Methods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class minimize {

	public static void main(String[] args) {
		// configure the browser
		WebDriverManager.chromedriver().setup();
		// launch the browser
		ChromeDriver driver = new ChromeDriver();
		// maximize the browser
		driver.manage().window().minimize();
		// optimized code
		// navigate to the application
		driver.get("https://www.myntra.com/");
		System.out.println();

	}
}