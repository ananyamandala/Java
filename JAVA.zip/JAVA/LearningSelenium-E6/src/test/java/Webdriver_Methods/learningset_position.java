package Webdriver_Methods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class learningset_position {

	public static void main(String[] args) {
		// configure the browser
				WebDriverManager.chromedriver().setup();
				// launch the browser
				ChromeDriver driver = new ChromeDriver();
				//set the position
				driver.manage().window().setPosition(new Point(100, 100));
				// navigate to the application
				driver.get("https://www.myntra.com/");
				driver.close();

			}
		}