package Webdriver_Methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Learning_get_current_url {

	public static void main(String[] args) {

		// Configure the browser
		WebDriverManager.chromedriver().setup();

		// Launch the browser
	WebDriver driver=new ChromeDriver();
	
	//navigate to the application via URL
	driver.get("https://www.myntra.com/");
	
	//fetch theCurrentURL
	String currenturl=driver.getCurrentUrl();
	
	//print on console
	System.out.println("current URL is :"+currenturl);

	
	//close  the browser
	driver.quit();
	
	}



	}


