package Webdriver_Methods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class getposition {

	public static void main(String[] args) {
		// configure the browser
		WebDriverManager.chromedriver().setup();
		// launch the browser
		ChromeDriver driver = new ChromeDriver();
		// maximize the browser
	Point position =driver.manage().window().getPosition();
		// optimized code
		// navigate to the application
		driver.get("https://www.myntra.com/");
		System.out.println("position is :"+position);

	}
}