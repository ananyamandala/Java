package Webdriver_Methods;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Learning_navigate_methods {

	public static void main(String[] args) throws InterruptedException,	MalformedURLException {
		
		// configure the browser
		
		WebDriverManager.chromedriver().setup();
		// launch the browser
		ChromeDriver driver = new ChromeDriver();
		
		Thread.sleep(1000);
		//Navigate to the application
		driver.get("https://www.myntra.com/");
		
		Thread.sleep(1000);
		//navigate to the application via navigate methods(method overloading is seen in navigating)
		driver.navigate().to("https://www.amazon.in/");
		
		Thread.sleep(1000);
		//navigate to the application via navigate methods
		driver.navigate().to(new URL("https://www.swiggy.com/"));
		
		Thread.sleep(1000);
		//perform backward direction
		driver.navigate().back();
		
		Thread.sleep(1000);
		//perform forward direction
		driver.navigate().forward();
		
		Thread.sleep(1000);
		//perform refresh
		driver.navigate().refresh();
		
		//close the browser
		driver.quit();
		
		
		
	}

}
