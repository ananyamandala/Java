package Webdriver_Methods;

import java.lang.classfile.ClassFile.Option;

import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LearningManage {

	public static void main(String[] args) {
		//configure the browser
		WebDriverManager.edgedriver().setup();
		//launch the browser
		EdgeDriver driver=new EdgeDriver();
		//maximize the browser
		Options optionobj=driver.manage();
		Window windowobj=optionobj.window();
		windowobj.maximize();
		//optimized code
		//navigate to the application
		driver.get("https://www.myntra.com/");
	}
}