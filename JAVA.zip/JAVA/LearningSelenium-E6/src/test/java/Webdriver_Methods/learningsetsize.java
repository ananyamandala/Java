package Webdriver_Methods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class learningsetsize {

	public static void main(String[] args) {
		// configure the browser
		WebDriverManager.chromedriver().setup();
		// launch the browser
		ChromeDriver driver = new ChromeDriver();
		//set the size
		driver.manage().window().setSize(new Dimension(100, 290));
		
		
		// navigate to the application
		driver.get("https://www.myntra.com/");
		driver.close();
		

	}
}