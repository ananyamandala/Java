package Webdriver_Methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class learningmethods_currentUrl {

	public static void main(String[] args) {
		// Configure the browser
		WebDriverManager.chromedriver().setup();

		// Launch the browser
	WebDriver driver=new ChromeDriver();
	
	//navigate to the application via URL
	driver.get("https://www.myntra.com/");
	
	//fetch the Title
	String acttitle=driver.getTitle();
	
	//print on console
	System.out.println("title is"+acttitle);
	
	if(acttitle.equals("Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra")) {
		System.out.println("title verified:Test pass");
	}
	else {
		System.out.println("title verified:Test fail");
	}
	}
}
	
	
	
	
	