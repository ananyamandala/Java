package Webdriver_Methods;

import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class fullscreen {

	public static void main(String[] args) {
		// configure the browser
		WebDriverManager.chromedriver().setup();
		// launch the browser
		ChromeDriver driver = new ChromeDriver();
		// fullscreen the browser
		driver.manage().window().fullscreen();
		// optimized code
		// navigate to the application
		driver.get("https://www.myntra.com/");

	}
}