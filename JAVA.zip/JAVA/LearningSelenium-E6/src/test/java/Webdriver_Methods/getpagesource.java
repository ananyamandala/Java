package Webdriver_Methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class getpagesource {

	public static void main(String[] args) {
		// Configure the browser
		WebDriverManager.chromedriver().setup();

		// Launch the browser
		WebDriver driver = new ChromeDriver();

		// navigate to the application via URL
		driver.get("https://www.myntra.com/");

		// get pagesource
		String pagesource = driver.getPageSource();

		// print on console
		System.out.println("pagesource is :" + pagesource);

		// close the browser
		driver.quit();

	}

}
